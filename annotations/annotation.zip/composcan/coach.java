package com.composcan;

public interface coach {
	String training();
}
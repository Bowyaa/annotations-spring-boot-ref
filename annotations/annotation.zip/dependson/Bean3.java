package com;

public class Bean3 {
	public Bean3() {
        System.out.println("Bean3 Initialized via Constructor");
    }

    public void display() {
        System.out.println("Bean3 method called");
    }
}

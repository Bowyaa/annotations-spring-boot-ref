package com;

public class Bean2 {
	public Bean2() {
        System.out.println("Bean2 Initialized via Constructor");
    }

    public void display() {
        System.out.println("Bean2 method called");
    }
}
